// I18N constants
// LANG: "sv" (Swedish), ENCODING: UTF-8
// translated: Erik Dalén, <dalen@jpl.se>
{
  "Maximize/Minimize Editor": "Maximera/Minimera WYSIWYG fönster"
};
