// I18N constants
// LANG: "nl", ENCODING: UTF-8
// Author: Maarten Molenschot, maarten@nrgmm.nl
{
  "definition list": "definitie lijst",
  "definition term": "definitie term",
  "definition description": "definitie omschrijving"
}