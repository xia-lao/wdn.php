// I18N constants
// LANG: "nl", ENCODING: UTF-8
// Author: Maarten Molenschot, maarten@nrgmm.nl
{ 
  "Insert Smiley": "Smiley invoegen",
  "Smiley": "Smiley",
  "Cancel": "Annuleren"
};