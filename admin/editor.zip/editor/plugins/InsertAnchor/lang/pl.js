// I18N constants
// LANG: "pl", ENCODING: UTF-8
// translated: Krzysztof Kotowicz koto@webworkers.pl
{
  "Insert Anchor": "Wstaw kotwicę",
  "Anchor name": "Nazwa kotwicy",
  "Delete": "Usuń"
};
