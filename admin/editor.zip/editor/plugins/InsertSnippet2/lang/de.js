// I18N constants
// LANG: "de", ENCODING: UTF-8
{ 
	"Insert Snippet": "Snippet einfügen",
	"Insert as HTML": "Als HTML einfügen",
	"HTML": "HTML",
	"Insert as template variable": "Als Template-Variable einfügen",
	"Variable": "Variable",
  "All Categories" : "Alle Kategorien",
  "Only search word beginning" : "Nur nach Wortanfang suchen",
  "Filter" : "Filter"
};