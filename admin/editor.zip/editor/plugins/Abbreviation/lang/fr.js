// I18N constants
// LANG: "fr", ENCODING: UTF-8
{
  "Abbreviation": "Abréviation",
  "Expansion:": "Explication",
  "Delete": "Supprimer"
};