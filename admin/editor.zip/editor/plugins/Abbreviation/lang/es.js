// I18N constants
// LANG: "en", ENCODING: UTF-8
// translated: Derick Leony <dleony@gmail.com>
{
  "Abbreviation": "Abreviatura",
  "Expansion:": "Explicación",
  "Delete": "Suprimir"
};
