// I18N constants
// LANG: "fr", ENCODING: UTF-8
{
  "Chars": "Caractères",
  "Words": "Mots"
};