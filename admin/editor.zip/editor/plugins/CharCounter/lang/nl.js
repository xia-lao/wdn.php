// I18N constants
// LANG: "nl", ENCODING: UTF-8
// Author: Maarten Molenschot, maarten@nrgmm.nl
{
  "Chars": "Tekens",
  "Words": "Woorden",
  "... in progress": "... wordt verwerkt"
};
