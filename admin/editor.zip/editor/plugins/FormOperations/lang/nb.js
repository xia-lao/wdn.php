// I18N constants
// LANG: "nb", ENCODING: UTF-8
// translated: Kim Steinhaug, http://www.steinhaug.com/, kim@steinhaug.com
{
  "Insert a Form.": "Sett inn skjema",
  "Insert a text, password or hidden field.": "Sett inn formfelt",
  "Insert a multi-line text field.": "Sett inn tekstfelt med flere linjer",
  "Insert a select field.": "Sett inn valgboks/ netrekksboks",
  "Insert a check box.": "Hakeboks",
  "Insert a radio button.": "Sett inn en radioknapp",
  "Insert a submit/reset button.": "Sett inn send-/nullstill knapp for skjemaet"
};